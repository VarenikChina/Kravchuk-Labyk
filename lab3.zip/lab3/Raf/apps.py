from django.apps import AppConfig


class RafConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Raf'
